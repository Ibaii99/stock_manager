Para cargar la base de datos ejecuta el siguiente comando:
sqlite3 donaciones.db < createDB_script.sql