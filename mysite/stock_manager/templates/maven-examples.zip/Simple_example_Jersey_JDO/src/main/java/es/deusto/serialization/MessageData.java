package es.deusto.serialization;

public class MessageData {

    private String message;

    public MessageData() {

    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}