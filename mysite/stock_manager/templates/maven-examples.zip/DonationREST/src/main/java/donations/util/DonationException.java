package donations.util;

public class DonationException extends Exception {

    public DonationException(String message) {
        super(message);
    }
}